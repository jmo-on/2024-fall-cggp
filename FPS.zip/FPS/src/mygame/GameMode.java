// Yongjae Lee
// Jin Hong Moon
// Kerry Wang

package mygame;

public enum GameMode {
    EASY,
    MEDIUM,
    HARD
} 