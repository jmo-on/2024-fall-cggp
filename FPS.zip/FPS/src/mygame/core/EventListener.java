package mygame.core;

import mygame.GameEvent;

public interface EventListener {
    void onEvent(GameEvent event);
} 